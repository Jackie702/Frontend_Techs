import React from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';

function CounterComponent(props) {

  const { counter, incrementCounter } = props

  return (
    <div>
      <Button onClick={incrementCounter} variant="contained" color="primary">
        Plus
      </Button>

      <form noValidate autoComplete="off">
        <TextField id="standard-basic" label="" value={counter}/>
      </form>
    </div>
  )
}

export default CounterComponent;