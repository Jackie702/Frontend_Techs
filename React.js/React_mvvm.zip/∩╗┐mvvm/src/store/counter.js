import { Subject } from "rxjs";

class Counter {
  
  constructor(height, width) {
    this.subject = new Subject()
    this.initialState = {
      'counter': 1
    }
    this.state = this.initialState
  }

  update(payload) {
    this.state = {
      ...this.state, ...payload
    };
    this.subject.next(this.state);
  }
}


export default Counter;