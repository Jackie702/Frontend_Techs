import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import CounterActions from './actions/counter';
import Counter from './store/counter';
import CounterComponent from './components/counter'

const _store = new Counter();
const actions = new CounterActions(_store);

function App() {

  const [store, setStore] = useState(_store.state)
  _store.subject.subscribe(setStore)

  return (
    <div className="App">
      <header className="App-header">
      <CounterComponent counter={store.counter} incrementCounter={actions.increment.bind(actions)} />
      </header>
    </div>
  );
}

export default App;
