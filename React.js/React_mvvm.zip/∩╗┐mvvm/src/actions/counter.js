
class CounterActions {

  constructor(store) {
    this.store = store
  }

  increment() {
    console.log("increment", this.store.state)
    this.store.update({
      'counter': this.store.state.counter + 1
    })
  }

}

export default CounterActions